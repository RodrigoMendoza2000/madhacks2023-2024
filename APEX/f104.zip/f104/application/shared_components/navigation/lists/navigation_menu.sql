prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>5716083853041667
,p_default_application_id=>104
,p_default_id_offset=>6116328087839079
,p_default_owner=>'MADHACKS'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(14250310491241826)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14544628720242093)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Home \D83C\DFE0')
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_text_02=>'link--text'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15451709026084609)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Explore Trends \2728')
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15455941014531548)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Generate Ideas \D83D\DCA1')
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18179458771193580)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('Analyze your audience \D83D\DCCA')
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18131880178857544)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>unistr('Settings \2699\FE0F')
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5'
);
wwv_flow_imp.component_end;
end;
/
