prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>5716083853041667
,p_default_application_id=>104
,p_default_id_offset=>6116328087839079
,p_default_owner=>'MADHACKS'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>unistr('Explore Trends \2728')
,p_alias=>'REPRODUCE-VIDEO-PLAYER'
,p_step_title=>unistr('Explore Trends \2728')
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#neptune.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'ANDRES.M.MARTINEZ@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20231106061641'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6723913010448910)
,p_plug_name=>'Bkg'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14371635756241899)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="bkg">',
'    <img class="bkg--image" src="#APP_FILES#bkg-2.jpg" />',
'</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6724091417448911)
,p_plug_name=>'Filters'
,p_parent_plug_id=>wwv_flow_imp.id(6723913010448910)
,p_region_css_classes=>'bubble--input--hand'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14371635756241899)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3 class="gradient--text">Explore Trends!</h3>',
'<br><br>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6724146982448912)
,p_plug_name=>'Filters'
,p_parent_plug_id=>wwv_flow_imp.id(6723913010448910)
,p_region_css_classes=>'bubble--output--hand'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14371635756241899)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<video class="hand--video" autoplay loop muted poster="#APP_FILES#hand.mp4">',
'    <source src="#APP_FILES#hand.mp4" type="video/mp4">',
'    </video>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14550786162248604)
,p_plug_name=>'Tiktok report'
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14309405607241871)
,p_plug_display_sequence=>70
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT v.AWEME_ID,''<video width="320" height="240" controls>',
'       <source src="''||apex_util.get_blob_file_src (''P2_VIDEO'', vb.AWEME_ID, ',
'       p_content_disposition => ''inline'')||''" type="video/mp4">',
'       our browser does not support the video tag.',
'       </video>'' as VIDEO,',
'       v.SUMMARY,',
'       a.DESC_VIDEO,',
'       LISTAGG(DISTINCT h.hashtag_name, '', '') WITHIN GROUP (ORDER BY hashtag_name) OVER (PARTITION BY h.aweme_id) as HASHTAGS,',
'       LISTAGG(DISTINCT t.topic, '', '') WITHIN GROUP (ORDER BY topic) OVER (PARTITION BY t.aweme_id) as TOPICS,',
'       m.title,',
'       m.author,',
'       s.digg_count as likes,',
'       v.transcript',
'       FROM VIDEO_BLOB vb',
'       JOIN VIDEO v',
'       ON v.AWEME_ID = vb.AWEME_ID',
'       JOIN AWEME a',
'       ON v.aweme_id = a.aweme_id',
'       JOIN HASHTAGS h',
'       ON h.aweme_id = a.aweme_id',
'       JOIN MUSIC_INFO m',
'       ON m.aweme_id = a.aweme_id',
'       JOIN STATISTICS s',
'       ON a.aweme_id = s.aweme_id',
'       FULL OUTER JOIN AWEME_TOPICS t',
'       ON a.aweme_id = t.aweme_id',
'       WHERE (:P2_TOPIC IS NULL OR t.topic = :P2_TOPIC)',
'       AND (:P2_HASHTAG IS NULL OR h.hashtag_id = :P2_HASHTAG)',
'       AND (:P2_MUSIC_TITLE IS NULL OR m.title = :P2_MUSIC_TITLE)',
'       AND (:P2_MUSIC_AUTHOR IS NULL OR m.author = :P2_MUSIC_AUTHOR)',
'       AND a.desc_video is not null;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P2_HASHTAG,P2_TOPIC,P2_MUSIC_TITLE,P2_MUSIC_AUTHOR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Tiktok report'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(14550856482248605)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'RODRIGO.R.MENDOZA@ORACLE.COM'
,p_internal_uid=>8434528394409526
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14550990101248606)
,p_db_column_name=>'AWEME_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Aweme Id'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14551077759248607)
,p_db_column_name=>'VIDEO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Video'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(19399364850501909)
,p_db_column_name=>'SUMMARY'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Summary'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(19399539900501911)
,p_db_column_name=>'DESC_VIDEO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tiktok description'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(19399630391501912)
,p_db_column_name=>'HASHTAGS'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Hashtags'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(19399813963501913)
,p_db_column_name=>'TOPICS'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Topics'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(19695849351947282)
,p_db_column_name=>'TITLE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Song title'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(19696020500947283)
,p_db_column_name=>'AUTHOR'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Song author'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6768775467678017)
,p_db_column_name=>'LIKES'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Likes'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6768835216678018)
,p_db_column_name=>'TRANSCRIPT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Transcript'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(15454704444108699)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'93384'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'TOPICS:HASHTAGS:DESC_VIDEO:TITLE:AUTHOR:LIKES:VIDEO:'
,p_sort_column_1=>'PLAY_COUNT'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14550509761248601)
,p_name=>'P2_VIDEO'
,p_item_sequence=>30
,p_use_cache_before_default=>'NO'
,p_source=>'DOWNLOADED_VIDEO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14550534739248602)
,p_name=>'P2_ID'
,p_item_sequence=>40
,p_use_cache_before_default=>'NO'
,p_source=>'AWEME_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19442208736372926)
,p_name=>'P2_TOPIC'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6724091417448911)
,p_prompt=>'Topic'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct topic as d, topic as r',
'from aweme_topics',
'order by d'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'All Topics'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_icon_css_classes=>'fa-question'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19442275030372927)
,p_name=>'P2_HASHTAG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6724091417448911)
,p_prompt=>'Hashtag'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct hashtag_name as d, hashtag_id as r',
'from hashtags',
'order by d'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'All Hashtags'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_icon_css_classes=>'fa-hashtag'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19696104044947284)
,p_name=>'P2_MUSIC_TITLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6724091417448911)
,p_prompt=>'Song title'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct title as d, title as r',
'from music_info',
'order by d'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'All Songs'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_icon_css_classes=>'fa-music'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19696197645947285)
,p_name=>'P2_MUSIC_AUTHOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6724091417448911)
,p_prompt=>'Artist'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct author as d, author as r',
'from music_info',
'order by d'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'All Artists'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_icon_css_classes=>'fa-user-man'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19442520427372929)
,p_name=>'Filters'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_TOPIC,P2_HASHTAG,P2_MUSIC_TITLE,P2_MUSIC_AUTHOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19695669426947280)
,p_event_id=>wwv_flow_imp.id(19442520427372929)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(14550786162248604)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14550643518248603)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'New'
,p_attribute_02=>'VIDEO_BLOB'
,p_attribute_03=>'P2_ID'
,p_attribute_04=>'AWEME_ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8434315430409524
);
wwv_flow_imp.component_end;
end;
/
