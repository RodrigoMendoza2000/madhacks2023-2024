prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>5716083853041667
,p_default_application_id=>104
,p_default_id_offset=>6116328087839079
,p_default_owner=>'MADHACKS'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'testapi'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#neptune.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'JORGE.F.FLORES@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20231106005522'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18094677396587380)
,p_plug_name=>'New'
,p_region_css_classes=>'main--container'
,p_region_template_options=>'margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(14371635756241899)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="landing--hero">',
'    <video id="landing--hero__video" autoplay loop muted poster="#APP_FILES#pexels-google-deepmind-18069232 (1080p).mp4">',
'    <source src="#APP_FILES#pexels-google-deepmind-18069232 (1080p).mp4" type="video/mp4">',
'    </video>',
'    ',
'',
'    ',
'',
'</div>',
'<div class="landing--hero__text">',
'        <h1 class="gradient--text">AI-powered</h1>',
'        <h2>Marketing Assistant</h2>',
'    </div>',
'',
'',
'<div class="features">',
'    <div class="features--item">',
'        <img src="#APP_FILES#understand.png" class="features--item__img">',
'        <div>',
'            <h1 class="features--item__h1">Explore Trends</h1>',
'            <p>Immerse yourself in the latest TikTok sensations, scroll through the most trending videos, and discover the hottest topics of the moment. </p>',
'        </div>',
'    </div>',
'    <div class="features--item">',
'        <img src="#APP_FILES#generate.png" class="features--item__img">',
'        <div>',
'            <h1 class="features--item__h1">Generate Ideas</h1><br>',
'            <p>Powered by Cohere AI, unleash your TikTok potential with effortlessly crafted video scripts and trending music.</p>',
'        </div>',
'    </div>',
'    <div class="features--item">',
'        <img src="#APP_FILES#analyze.png" class="features--item__img">',
'        <div>',
'            <h1 class="features--item__h1">Analyze your audience</h1>',
'            <p>Discover top hashtags, trending topics, and TikTok hits in your niche through amazing charts to understand this ever-evolving community.</p>',
'        </div>',
'    </div>',
'',
'</div>',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18277869708030480)
,p_plug_name=>'New'
,p_region_template_options=>'margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(14371635756241899)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14557154248325483)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GeTikToks'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'declare',
'    l_clob      CLOB;',
'BEGIN',
' ',
'    l_clob := apex_web_service.make_rest_request(',
'        p_url => ''http://34.125.21.149/tiktok/insertTikTok'',',
'        p_http_method => ''GET'',',
'        p_parm_name => apex_util.string_to_table(''keyword:count''),',
'        p_parm_value => apex_util.string_to_table(:P1_KEYWORD || '':'' || :P1_COUNT)',
'        );',
' ',
'END;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8440826160486404
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14557458779325486)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Truncate'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  BEGIN',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE AUTHOR'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE HASHTAGS'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE MUSIC_INFO'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE SHARE_INFO'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE STATISTICS'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE VIDEO'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE VIDEO_URL'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE VIDEO_BLOB'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE AWEME_TOPICS'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE AWEME'';',
'  END;',
'  ',
'  COMMIT;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8441130691486407
);
wwv_flow_imp.component_end;
end;
/
