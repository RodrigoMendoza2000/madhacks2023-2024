prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>5716083853041667
,p_default_application_id=>104
,p_default_id_offset=>6116328087839079
,p_default_owner=>'MADHACKS'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'cohere_response'
,p_alias=>'COHERE-RESPONSE'
,p_step_title=>'cohere_response'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#neptune.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.text_display {',
'    text-align: center;',
'    text-shadow: 2px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'JORGE.F.FLORES@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20231106020317'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6723313195448904)
,p_plug_name=>'Image'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14371635756241899)
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="bkg">',
'    <img class="bkg--image--cohere" src="#APP_FILES#bkg-2.jpg" />',
'</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6723434052448905)
,p_plug_name=>'Input'
,p_parent_plug_id=>wwv_flow_imp.id(6723313195448904)
,p_region_css_classes=>'bubble--input'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14371635756241899)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3 class="gradient--text">Running out of ideas? Let Cohere help you! </h3>',
'<br><br>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6723591467448906)
,p_plug_name=>'Output'
,p_parent_plug_id=>wwv_flow_imp.id(6723313195448904)
,p_region_css_classes=>'bubble--output'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14371635756241899)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6723632606448907)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(6723591467448906)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14371635756241899)
,p_plug_display_sequence=>20
,p_plug_source=>'<img src="#APP_FILES#prompt.png"/>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15456474295531565)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14322907945241876)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(14249810057241823)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(14427845478241934)
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18203880349415687)
,p_plug_name=>'Other'
,p_region_template_options=>'#DEFAULT#:margin-top-lg'
,p_plug_template=>wwv_flow_imp.id(14371635756241899)
,p_plug_display_sequence=>50
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18204050770415689)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(18203880349415687)
,p_button_name=>'VIDEOS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--stretch:t-Button--padTop:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(14426394049241934)
,p_button_image_alt=>'Get Inspired'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-magic'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18203952573415688)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(18203880349415687)
,p_button_name=>'ANALYTICS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--stretch:t-Button--padTop:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(14426394049241934)
,p_button_image_alt=>'Analytics'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-star'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14551271042248609)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6723434052448905)
,p_button_name=>'response'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--success:t-Button--iconLeft:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(14426394049241934)
,p_button_image_alt=>'Generate Ideas'
,p_button_position=>'NEXT'
,p_button_css_classes=>'btn--belico'
,p_icon_css_classes=>'fa-send'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6867524761348401)
,p_name=>'P3_HASHTAGS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6723434052448905)
,p_prompt=>'Select the hashtags for you new script'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct HASHTAG_NAME as d, HASHTAG_NAME AS r',
'FROM HASHTAGS',
'WHERE LENGTH(HASHTAG_NAME) > 3'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_icon_css_classes=>'fa-hashtag'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_attribute_11=>','
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6867790547348403)
,p_name=>'P3_TIKTOKER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6723434052448905)
,p_prompt=>'Select a specific Tiktoker'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT nickname as d, nickname AS r',
'FROM AUTHOR'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_icon_css_classes=>'fa-users'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_attribute_11=>','
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6867873118348404)
,p_name=>'P3_SONG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(6723434052448905)
,p_prompt=>'Select a specific Song'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct TITLE as d, TITLE AS r',
'FROM MUSIC_INFO',
'WHERE TITLE NOT LIKE ''%original sound%'''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_icon_css_classes=>'fa-music'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6867957176348405)
,p_name=>'P3_TOPICS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(6723434052448905)
,p_prompt=>'Select topics'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT distinct TOPIC as d, TOPIC AS r',
'FROM AWEME_TOPICS'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_attribute_11=>','
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14551157854248608)
,p_name=>'P3_PROMPT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(6723434052448905)
,p_placeholder=>'Write your prompt'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>100
,p_cMaxlength=>300
,p_cHeight=>8
,p_field_template=>wwv_flow_imp.id(14423651421241930)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14551389833248610)
,p_name=>'P3_RESPONSE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6723591467448906)
,p_display_as=>'NATIVE_MARKDOWN_EDITOR'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_css_classes=>'cohere--output'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'NONE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(18205554230415704)
,p_name=>'New_1'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18205800539415706)
,p_event_id=>wwv_flow_imp.id(18205554230415704)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(18203880349415687)
,p_server_condition_type=>'ITEM_IS_NOT_NULL'
,p_server_condition_expr1=>'P3_RESPONSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6868076412348406)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_HASHTAGS,P3_TIKTOKER,P3_SONG,P3_TOPICS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6868139579348407)
,p_event_id=>wwv_flow_imp.id(6868076412348406)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_PROMPT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''',
'Write a possible TikTok script in english about ''|| :P3_TOPICS || '', with the hashtags being '' || :P3_HASHTAGS || ''. Have the background music be ''|| :P3_SONG || '' And similar to the TikToker '' || :P3_TIKTOKER AS topic',
'FROM dual'))
,p_attribute_07=>'P3_HASHTAGS,P3_TIKTOKER,P3_SONG,P3_TOPICS'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14551430138248611)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'l_response VARCHAR2(4000);',
'BEGIN',
'',
'l_response := COHERE_RESPONSE(:P3_PROMPT);',
'',
':P3_RESPONSE := l_response;',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(14551271042248609)
,p_internal_uid=>8435102050409532
);
wwv_flow_imp.component_end;
end;
/
