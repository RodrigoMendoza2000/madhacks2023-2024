prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>5716083853041667
,p_default_application_id=>104
,p_default_id_offset=>6116328087839079
,p_default_owner=>'MADHACKS'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Get Tiktoks'
,p_alias=>'GET-TIKTOKS'
,p_step_title=>'Get Tiktoks'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'JORGE.F.FLORES@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20231030010340'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26511679241978761)
,p_plug_name=>'testapi'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(14342773382241884)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(26514503719985244)
,p_name=>'tiktok report'
,p_template=>wwv_flow_imp.id(14361856586241894)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'SELECT * FROM aweme'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14388669673241909)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18083523133575777)
,p_query_column_id=>1
,p_column_alias=>'AWEME_ID'
,p_column_display_sequence=>10
,p_column_heading=>'Aweme Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18083919306575778)
,p_query_column_id=>2
,p_column_alias=>'CREATE_TIME'
,p_column_display_sequence=>20
,p_column_heading=>'Create Time'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18084244576575779)
,p_query_column_id=>3
,p_column_alias=>'DESC_VIDEO'
,p_column_display_sequence=>30
,p_column_heading=>'Desc Video'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18084670640575779)
,p_query_column_id=>4
,p_column_alias=>'DESC_LANGUAGE'
,p_column_display_sequence=>40
,p_column_heading=>'Desc Language'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(26515650749985256)
,p_name=>'aweme_videos'
,p_template=>wwv_flow_imp.id(14361856586241894)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'select aweme_id, dbms_lob.getlength(downloaded_video) as downloaded_video, mime_type, mime_name from VIDEO_BLOB'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14388669673241909)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18085476627575780)
,p_query_column_id=>1
,p_column_alias=>'AWEME_ID'
,p_column_display_sequence=>10
,p_column_heading=>'Aweme Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18085867934575780)
,p_query_column_id=>2
,p_column_alias=>'DOWNLOADED_VIDEO'
,p_column_display_sequence=>20
,p_column_heading=>'Downloaded Video'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:VIDEO_BLOB:DOWNLOADED_VIDEO:AWEME_ID::MIME_TYPE:MIME_NAME:::attachment::'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18086244072575781)
,p_query_column_id=>3
,p_column_alias=>'MIME_TYPE'
,p_column_display_sequence=>30
,p_column_heading=>'Mime Type'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18086706216575781)
,p_query_column_id=>4
,p_column_alias=>'MIME_NAME'
,p_column_display_sequence=>40
,p_column_heading=>'Mime Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18087222883575793)
,p_button_sequence=>30
,p_button_name=>'GetTikToks'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(14426281116241933)
,p_button_image_alt=>'Get TikToks'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18087625378575794)
,p_button_sequence=>40
,p_button_name=>'Truncate'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(14426281116241933)
,p_button_image_alt=>'Truncate Tables'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26528579476062196)
,p_name=>'P4_KEYWORD'
,p_item_sequence=>10
,p_prompt=>'Keyword'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26528915804062200)
,p_name=>'P4_COUNT'
,p_item_sequence=>20
,p_prompt=>'Count'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18088686968575799)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GeTikToks'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'declare',
'    l_clob      CLOB;',
'BEGIN',
' ',
'    l_clob := apex_web_service.make_rest_request(',
'        p_url => ''http://34.125.21.149/tiktok/insertTikTok'',',
'        p_http_method => ''GET'',',
'        p_parm_name => apex_util.string_to_table(''keyword:count''),',
'        p_parm_value => apex_util.string_to_table(:P4_KEYWORD || '':'' || :P4_COUNT)',
'        );',
' ',
'END;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(18087222883575793)
,p_internal_uid=>11972358880736720
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18089118732575799)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Truncate'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  BEGIN',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE AUTHOR'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE HASHTAGS'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE MUSIC_INFO'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE SHARE_INFO'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE STATISTICS'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE VIDEO'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE VIDEO_URL'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE VIDEO_BLOB'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE AWEME_TOPICS'';',
'    EXECUTE IMMEDIATE ''TRUNCATE TABLE AWEME'';',
'  END;',
'  ',
'  COMMIT;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(18087625378575794)
,p_internal_uid=>11972790644736720
);
wwv_flow_imp.component_end;
end;
/
