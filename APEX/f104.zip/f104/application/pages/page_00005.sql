prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>5716083853041667
,p_default_application_id=>104
,p_default_id_offset=>6116328087839079
,p_default_owner=>'MADHACKS'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Request TikToks'
,p_alias=>'REQUEST-TIKTOKS'
,p_step_title=>'Request TikToks'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#neptune.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'ANDRES.M.MARTINEZ@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20231106032149'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6723068738448901)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14371635756241899)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="bkg">',
'    <img class="bkg--image" src="#APP_FILES#bkg-2.jpg" />',
'</div>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18203553460415684)
,p_plug_name=>'bubble'
,p_parent_plug_id=>wwv_flow_imp.id(6723068738448901)
,p_region_css_classes=>'bubble'
,p_region_template_options=>'margin-bottom-lg'
,p_plug_template=>wwv_flow_imp.id(14371635756241899)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3 class="gradient--text">Customize the content! </h3>',
'<br><br>',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18132402511857550)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14322907945241876)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(14249810057241823)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(14427845478241934)
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18203357599415682)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(18203553460415684)
,p_button_name=>'SUBMIT_BUTTON'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'t-Button--large:t-Button--primary:t-Button--iconLeft:t-Button--hoverIconPush:t-Button--gapLeft:t-Button--gapRight:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(14426394049241934)
,p_button_image_alt=>'Get me Tiktoks'
,p_button_position=>'NEXT'
,p_button_css_classes=>'btn--belico'
,p_icon_css_classes=>'fa-magic'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14551628449248613)
,p_name=>'P5_TOPIC'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(18203553460415684)
,p_prompt=>'Keyword'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_icon_css_classes=>'fa-question'
,p_item_template_options=>'#DEFAULT#:margin-left-md'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14551862541248615)
,p_name=>'P5_COUNT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(18203553460415684)
,p_item_default=>'30'
,p_prompt=>'Quantity'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>2
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#:margin-bottom-md:margin-right-md'
,p_attribute_01=>'1'
,p_attribute_02=>'600'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14551966391248616)
,p_name=>'P5_SORT_TYPE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(18203553460415684)
,p_item_default=>'1'
,p_prompt=>'Filter By'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Most liked;1,Relevance;0'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_icon_css_classes=>'fa-filter'
,p_item_template_options=>'#DEFAULT#:margin-bottom-md'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14552076191248617)
,p_name=>'P5_PUBLISH_TIME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(18203553460415684)
,p_item_default=>'30'
,p_prompt=>'Period'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Yesterday;1,This week;7,This month;30,Last 3 months;90,Last 6 months;180,All time;0'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_icon_css_classes=>'fa-calendar'
,p_item_template_options=>'#DEFAULT#:margin-bottom-md:margin-left-md:margin-right-md'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14552141343248618)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Extract_tiktok'
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_04=>'IGNORE'
,p_attribute_06=>'3'
,p_process_error_message=>'not wooo'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(18203357599415682)
,p_process_success_message=>'Tiktoks successfully downloaded!'
,p_internal_uid=>8435813255409539
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14552362795248620)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  DECLARE',
'    l_clob           CLOB;',
'    v_offset         NUMBER;',
'    v_count          NUMBER;',
'    v_request_count  NUMBER;',
'    v_max_videos_per_request NUMBER := 30;',
'    v_count_for_request NUMBER;',
'  BEGIN',
'    v_count := TO_NUMBER(:P5_COUNT);',
'    v_request_count := CEIL(v_count / v_max_videos_per_request);',
'',
'    FOR i IN 1..v_request_count LOOP',
'      v_offset := (i - 1) * v_max_videos_per_request;',
'      -- Calculate the number of videos to request for the current iteration',
'      v_count_for_request := LEAST(v_max_videos_per_request, v_count - (i - 1) * v_max_videos_per_request);',
'',
'      l_clob := apex_web_service.make_rest_request(',
'        p_url => ''http://159.54.143.150/tiktok/insertTikTok'',',
'        p_http_method => ''GET'',',
'        p_parm_name => apex_util.string_to_table(''keyword:count:publish_time:sort_type:offset''),',
'        p_parm_value => apex_util.string_to_table(:P5_TOPIC || '':'' || v_count_for_request || '':'' || :P5_PUBLISH_TIME || '':''|| :P5_SORT_TYPE || '':'' || v_offset)',
'      );',
'',
'      -- Process the response here if needed',
'    END LOOP;',
'  END;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(18203357599415682)
,p_process_when_type=>'NEVER'
,p_internal_uid=>8436034707409541
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14552232249248619)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(14552141343248618)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  DECLARE',
'    l_clob           CLOB;',
'    v_offset         NUMBER;',
'    v_count          NUMBER;',
'    v_request_count  NUMBER;',
'    v_max_videos_per_request NUMBER := 30;',
'    v_count_for_request NUMBER;',
'  BEGIN',
'    v_count := TO_NUMBER(:P5_COUNT);',
'    v_request_count := CEIL(v_count / v_max_videos_per_request);',
'',
'    FOR i IN 1..v_request_count LOOP',
'      v_offset := (i - 1) * v_max_videos_per_request;',
'      -- Calculate the number of videos to request for the current iteration',
'      v_count_for_request := LEAST(v_max_videos_per_request, v_count - (i - 1) * v_max_videos_per_request);',
'',
'      l_clob := apex_web_service.make_rest_request(',
'        p_url => ''http://159.54.136.12/tiktok/insertTikTok'',',
'        p_http_method => ''GET'',',
'        p_parm_name => apex_util.string_to_table(''keyword:count:publish_time:sort_type:offset''),',
'        p_parm_value => apex_util.string_to_table(:P5_TOPIC || '':'' || v_count_for_request || '':'' || :P5_PUBLISH_TIME || '':''|| :P5_SORT_TYPE || '':'' || v_offset)',
'      );',
'',
'      -- Process the response here if needed',
'    END LOOP;',
'  END;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'uh oh'
,p_process_when_button_id=>wwv_flow_imp.id(18203357599415682)
,p_process_success_message=>'yeii'
,p_internal_uid=>8435904161409540
);
wwv_flow_imp.component_end;
end;
/
