prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>5716083853041667
,p_default_application_id=>104
,p_default_id_offset=>6116328087839079
,p_default_owner=>'MADHACKS'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Analytics'
,p_alias=>'ANALYTICS'
,p_step_title=>'Analytics'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>'#APP_FILES#neptune.css'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
,p_last_updated_by=>'ANDRES.M.MARTINEZ@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20231106062320'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6768201736678012)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19044422856018727)
,p_plug_name=>'Word cloud - topics'
,p_parent_plug_id=>wwv_flow_imp.id(6768201736678012)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.topic as chart_text,',
'       sum(s.play_count) as chart_value,',
'       ''Topic'' as chart_group',
'from statistics s',
'join aweme_topics t',
'on s.aweme_id = t.aweme_id',
'group by t.topic',
'order by chart_value desc',
'fetch first 50 rows only'))
,p_plug_source_type=>'PLUGIN_ORCLKING.TAG.CLOUD'
,p_attribute_01=>'900'
,p_attribute_02=>'400'
,p_attribute_03=>'Word Cloud - Topics'
,p_attribute_04=>'0, -45, 90'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19280633467155399)
,p_plug_name=>'Word Cloud - Hashtags'
,p_parent_plug_id=>wwv_flow_imp.id(6768201736678012)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select h.hashtag_name as chart_text,',
'       sum(s.play_count) as chart_value,',
'       ''Hashtag'' as chart_group',
'from statistics s',
'join hashtags h',
'on s.aweme_id = h.aweme_id',
'group by h.hashtag_name',
'order by chart_value desc',
'fetch first 50 rows only'))
,p_plug_source_type=>'PLUGIN_ORCLKING.TAG.CLOUD'
,p_attribute_01=>'900'
,p_attribute_02=>'400'
,p_attribute_03=>'Word Cloud - Hashtags'
,p_attribute_04=>'0, -45, 90'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18179976624193583)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14322907945241876)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(14249810057241823)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(14427845478241934)
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19039631503018680)
,p_plug_name=>'Tabs Container'
,p_region_css_classes=>'charts--container'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(14357902125241892)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19044485849018728)
,p_plug_name=>'Engagement by Topic'
,p_parent_plug_id=>wwv_flow_imp.id(19039631503018680)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19044618971018729)
,p_plug_name=>'Filters'
,p_parent_plug_id=>wwv_flow_imp.id(19044485849018728)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14327931109241878)
,p_plug_display_sequence=>40
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19280750210155400)
,p_plug_name=>'Compare two topics'
,p_parent_plug_id=>wwv_flow_imp.id(19044485849018728)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19280828403155401)
,p_plug_name=>'Statistics first topic'
,p_region_name=>'first_topic'
,p_parent_plug_id=>wwv_flow_imp.id(19280750210155400)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'BEGIN',
'',
'if :P6_AVERAGE_TOPIC = 0 then',
'    l_sql := q''~ select sum(s.comment_count) as value, ''Comments'' as label ',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all',
'select  sum(s.digg_count) as value, ''Likes'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all',
'select  sum(s.play_count) as value, ''Views'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all ',
'select  sum(s.download_count) as value, ''Downloads'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all',
'select  sum(s.share_count) as value, ''Shares'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all',
'select  sum(s.whatsapp_share_count) as value, ''Whatsapp Shares'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'',
'',
' ~'';',
'',
'else ',
'    l_sql := q''~ select sum(s.comment_count)/ count(t.aweme_id) as value, ''Comments'' as label ',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all',
'select  sum(s.digg_count)/ count(t.aweme_id) as value, ''Likes'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all',
'select  sum(s.play_count)/ count(t.aweme_id) as value, ''Views'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all ',
'select  sum(s.download_count)/ count(t.aweme_id) as value, ''Downloads'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all',
'select  sum(s.share_count)/ count(t.aweme_id) as value, ''Shares'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all',
'select  sum(s.whatsapp_share_count)/ count(t.aweme_id) as value, ''Whatsapp Shares'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
' ~'';',
'end if;',
'',
'return l_sql;',
'',
'END;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sum(s.comment_count) as value, ''comments'' as label ',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all ',
'select  sum(s.download_count) as value, ''downloads'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all',
'select  sum(s.play_count) as value, ''views'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all',
'select  sum(s.share_count) as value, ''shares'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic',
'union all',
'select  sum(s.whatsapp_share_count) as value, ''whatsapp shares'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_1',
' group by',
'        t.topic'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(19281088996155403)
,p_region_id=>wwv_flow_imp.id(19280828403155401)
,p_chart_type=>'donut'
,p_title=>'First topic'
,p_height=>'300'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlightAndExplode'
,p_no_data_found_message=>'No data found'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){',
'',
'    options.styleDefaults = { pieInnerRadius: 0.85 };',
'    options.pieCenter = { label : $v("P6_TOPIC_1")};// + " "+$v("P8_HC_INTERN_1") };',
'    ',
'    options.dataFilter = function( data ) { ',
'        var groupLength = data.series.length;',
'        if (groupLength == 1){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            return data; ',
'        }else if(groupLength == 2){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            return data; ',
'        }else if(groupLength == 3){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            return data;  ',
'        }else if(groupLength == 4){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            return data;',
'        }else if(groupLength == 5){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            return data; ',
'        }else if(groupLength ==6){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            data.series[ 5 ].color = "#a8a4e4";',
'            return data;',
'        }else',
'            return data;',
'    };',
'    return options;',
'} ',
'',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19281201280155404)
,p_chart_id=>wwv_flow_imp.id(19281088996155403)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19281979511155412)
,p_plug_name=>'Statistics second topic'
,p_region_name=>'second_topic'
,p_parent_plug_id=>wwv_flow_imp.id(19280750210155400)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'BEGIN',
'',
'if :P6_AVERAGE_TOPIC = 0 then',
'    l_sql := q''~ select sum(s.comment_count) as value, ''Comments'' as label ',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_2',
' group by',
'        t.topic',
'union all',
'select  sum(s.digg_count) as value, ''Likes'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_2',
' group by',
'        t.topic',
'union all',
'select  sum(s.play_count) as value, ''Views'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_2',
' group by',
'        t.topic',
'union all ',
'select  sum(s.download_count) as value, ''Downloads'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_2',
' group by',
'        t.topic',
'union all',
'select  sum(s.share_count) as value, ''Shares'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_2',
' group by',
'        t.topic',
'union all',
'select  sum(s.whatsapp_share_count) as value, ''Whatsapp Shares'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_2',
' group by',
'        t.topic',
' ~'';',
'',
'else ',
'    l_sql := q''~ select sum(s.comment_count)/ count(t.aweme_id) as value, ''Comments'' as label ',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_2',
' group by',
'        t.topic',
'union all',
'select  sum(s.digg_count)/ count(t.aweme_id) as value, ''Likes'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_2',
' group by',
'        t.topic',
'union all',
'select  sum(s.play_count)/ count(t.aweme_id) as value, ''Views'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_2',
' group by',
'        t.topic',
'union all ',
'select  sum(s.download_count)/ count(t.aweme_id) as value, ''Downloads'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_2',
' group by',
'        t.topic',
'union all',
'select  sum(s.share_count)/ count(t.aweme_id) as value, ''Shares'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_2',
' group by',
'        t.topic',
'union all',
'select  sum(s.whatsapp_share_count)/ count(t.aweme_id) as value, ''Whatsapp Shares'' as label',
' from statistics s',
' join aweme a',
' on s.aweme_id = a.aweme_id',
' join aweme_topics t',
' on t.aweme_id = a.aweme_id',
' where t.topic = :P6_TOPIC_2',
' group by',
'        t.topic',
' ~'';',
'end if;',
'',
'return l_sql;',
'',
'END;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(19282045267155413)
,p_region_id=>wwv_flow_imp.id(19281979511155412)
,p_chart_type=>'donut'
,p_title=>'Second Topic'
,p_height=>'300'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'auto'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlightAndExplode'
,p_no_data_found_message=>'No data found'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){',
'',
'    options.styleDefaults = { pieInnerRadius: 0.85 };',
'    options.pieCenter = { label :$v("P6_TOPIC_2") + " " };',
'    ',
'    options.dataFilter = function( data ) { ',
'        var groupLength = data.series.length;',
'        if (groupLength == 1){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            return data; ',
'        }else if(groupLength == 2){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            return data; ',
'        }else if(groupLength == 3){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            return data;  ',
'        }else if(groupLength == 4){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            return data;',
'        }else if(groupLength == 5){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            return data; ',
'        }else if(groupLength ==6){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            data.series[ 5 ].color = "#a8a4e4";',
'            return data;',
'        }else',
'            return data;',
'    };',
'    return options;',
'} ',
'',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19282224392155414)
,p_chart_id=>wwv_flow_imp.id(19282045267155413)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19438711149372891)
,p_plug_name=>'Total Engagement by Topic'
,p_region_name=>'EngagementByTopic'
,p_parent_plug_id=>wwv_flow_imp.id(19044485849018728)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(19438790237372892)
,p_region_id=>wwv_flow_imp.id(19438711149372891)
,p_chart_type=>'bar'
,p_title=>'Total Engagement by Topic'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'value-desc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){',
'',
'    //options.styleDefaults = { pieInnerRadius: 0.85 };',
'    //options.pieCenter = { label : apex.item("P6_TOPIC_1").getValue() + "Printing something"};',
'    ',
'    options.dataFilter = function( data ) { ',
'        var groupLength = data.series.length;',
'        if (groupLength == 1){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            return data; ',
'        }else if(groupLength == 2){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            return data; ',
'        }else if(groupLength == 3){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            return data;  ',
'        }else if(groupLength == 4){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            return data;',
'        }else if(groupLength == 5){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            return data; ',
'        }else if(groupLength ==6){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            data.series[ 5 ].color = "#a8a4e4";',
'            return data;',
'        }else',
'            return data;',
'    };',
'    return options;',
'} ',
'',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19438918080372893)
,p_chart_id=>wwv_flow_imp.id(19438790237372892)
,p_seq=>10
,p_name=>'Comments'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'l_sql := q''~ select sum(s.comment_count) ~'';',
'',
'if :P6_AVERAGE_TOPIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Comments'' as series, t.topic as label ',
'         from statistics s',
'         join aweme_topics t',
'         on t.aweme_id = s.aweme_id',
'         group by',
'                t.topic',
'         order by sum(s.play_count) desc',
'        ~'';',
'else',
'    l_sql := l_sql || q''~ / count(t.aweme_id) as value, ''Comments'' as series, t.topic as label ',
'         from statistics s',
'         join aweme_topics t',
'         on t.aweme_id = s.aweme_id',
'         group by',
'                t.topic',
'         order by sum(s.play_count) desc',
'         ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_TOPICS rows only ~'';',
'    ',
'return l_sql;',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6767158436678001)
,p_chart_id=>wwv_flow_imp.id(19438790237372892)
,p_seq=>20
,p_name=>'Likes'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'l_sql := q''~ select sum(s.digg_count) ~'';',
'',
'if :P6_AVERAGE_TOPIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Likes'' as series, t.topic as label ',
'         from statistics s',
'         join aweme_topics t',
'         on t.aweme_id = s.aweme_id',
'         group by',
'                t.topic',
'         order by sum(s.play_count) desc',
'        ~'';',
'else',
'    l_sql := l_sql || q''~ / count(t.aweme_id) as value, ''Likes'' as series, t.topic as label ',
'         from statistics s',
'         join aweme_topics t',
'         on t.aweme_id = s.aweme_id',
'         group by',
'                t.topic',
'         order by sum(s.play_count) desc',
'         ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_TOPICS rows only ~'';',
'    ',
'return l_sql;',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19439064792372895)
,p_chart_id=>wwv_flow_imp.id(19438790237372892)
,p_seq=>30
,p_name=>'Views'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'l_sql := q''~ select sum(s.play_count) ~'';',
'',
'if :P6_AVERAGE_TOPIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Views'' as series, t.topic as label ',
'         from statistics s',
'         join aweme_topics t',
'         on t.aweme_id = s.aweme_id',
'         group by',
'                t.topic',
'         order by sum(s.play_count) desc',
'        ~'';',
'else',
'    l_sql := l_sql || q''~ / count(t.aweme_id) as value, ''Views'' as series, t.topic as label ',
'         from statistics s',
'         join aweme_topics t',
'         on t.aweme_id = s.aweme_id',
'         group by',
'                t.topic',
'         order by sum(s.play_count) desc',
'         ~'';',
'end if;',
'',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_TOPICS rows only ~'';',
'    ',
'',
'return l_sql;',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19438959379372894)
,p_chart_id=>wwv_flow_imp.id(19438790237372892)
,p_seq=>40
,p_name=>'Downloads'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'l_sql := q''~ select sum(s.download_count) ~'';',
'',
'if :P6_AVERAGE_TOPIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Downloads'' as series, t.topic as label ',
'         from statistics s',
'         join aweme_topics t',
'         on t.aweme_id = s.aweme_id',
'         group by',
'                t.topic',
'         order by sum(s.play_count) desc',
'        ~'';',
'else',
'    l_sql := l_sql || q''~ / count(t.aweme_id) as value, ''Downloads'' as series, t.topic as label ',
'         from statistics s',
'         join aweme_topics t',
'         on t.aweme_id = s.aweme_id',
'         group by',
'                t.topic',
'         order by sum(s.play_count) desc',
'         ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_TOPICS rows only ~'';',
'    ',
'return l_sql;',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19439165188372896)
,p_chart_id=>wwv_flow_imp.id(19438790237372892)
,p_seq=>60
,p_name=>'Shares'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'l_sql := q''~ select sum(s.share_count) ~'';',
'',
'if :P6_AVERAGE_TOPIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Shares'' as series, t.topic as label ',
'         from statistics s',
'         join aweme_topics t',
'         on t.aweme_id = s.aweme_id',
'         group by',
'                t.topic',
'         order by sum(s.play_count) desc',
'        ~'';',
'else',
'    l_sql := l_sql || q''~ / count(t.aweme_id) as value, ''Shares'' as series, t.topic as label ',
'         from statistics s',
'         join aweme_topics t',
'         on t.aweme_id = s.aweme_id',
'         group by',
'                t.topic',
'         order by sum(s.play_count) desc',
'         ~'';',
'end if;',
'',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_TOPICS rows only ~'';',
'    ',
'',
'return l_sql;',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19439261406372897)
,p_chart_id=>wwv_flow_imp.id(19438790237372892)
,p_seq=>70
,p_name=>'Whatsapp shares'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'l_sql := q''~ select sum(s.whatsapp_share_count) ~'';',
'',
'if :P6_AVERAGE_TOPIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Whatsapp Shares'' as series, t.topic as label ',
'         from statistics s',
'         join aweme_topics t',
'         on t.aweme_id = s.aweme_id',
'         group by',
'                t.topic',
'         order by sum(s.play_count) desc',
'        ~'';',
'else',
'    l_sql := l_sql || q''~ / count(t.aweme_id) as value, ''Whatsapp_shares'' as series, t.topic as label ',
'         from statistics s',
'         join aweme_topics t',
'         on t.aweme_id = s.aweme_id',
'         group by',
'                t.topic',
'         order by sum(s.play_count) desc',
'         ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_TOPICS rows only ~'';',
'    ',
'return l_sql;',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(19439358457372898)
,p_chart_id=>wwv_flow_imp.id(19438790237372892)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Topic'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>5716083853041667
,p_default_application_id=>104
,p_default_id_offset=>6116328087839079
,p_default_owner=>'MADHACKS'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(19439465732372899)
,p_chart_id=>wwv_flow_imp.id(19438790237372892)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Interactions'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19278776715155380)
,p_plug_name=>'Engagement by Hashtag'
,p_parent_plug_id=>wwv_flow_imp.id(19039631503018680)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19278889692155381)
,p_plug_name=>'Filters'
,p_parent_plug_id=>wwv_flow_imp.id(19278776715155380)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14327931109241878)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19279183613155384)
,p_plug_name=>'Total Engagement by Hashtag'
,p_region_name=>'EngagementByHashtag'
,p_parent_plug_id=>wwv_flow_imp.id(19278776715155380)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(19279320179155385)
,p_region_id=>wwv_flow_imp.id(19279183613155384)
,p_chart_type=>'bar'
,p_title=>'Total Engagement by Hashtag'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'value-desc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){',
'',
'    //options.styleDefaults = { pieInnerRadius: 0.85 };',
'    //options.pieCenter = { label : apex.item("P6_TOPIC_1").getValue() + "Printing something"};',
'    ',
'    options.dataFilter = function( data ) { ',
'        var groupLength = data.series.length;',
'        if (groupLength == 1){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            return data; ',
'        }else if(groupLength == 2){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            return data; ',
'        }else if(groupLength == 3){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            return data;  ',
'        }else if(groupLength == 4){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            return data;',
'        }else if(groupLength == 5){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            return data; ',
'        }else if(groupLength ==6){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            data.series[ 5 ].color = "#a8a4e4";',
'            return data;',
'        }else',
'            return data;',
'    };',
'    return options;',
'} ',
'',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19279381363155386)
,p_chart_id=>wwv_flow_imp.id(19279320179155385)
,p_seq=>10
,p_name=>'Comments'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'l_sql := q''~select sum(s.comment_count) ~'';',
'',
'if :P6_AVERAGE_HASHTAG = 0 then',
'    l_sql := l_sql || q''~ ',
'     as value, ''Comments'' as series, h.hashtag_name as label ',
'     from statistics s',
'     join aweme a',
'     on s.aweme_id = a.aweme_id',
'     join hashtags h',
'     on h.aweme_id = a.aweme_id',
'     group by',
'            h.hashtag_name',
'     order by sum(s.play_count) desc',
'     ~'';',
'else',
'    l_sql := l_sql || q''~',
'     /count(h.aweme_id) as value, ''Comments'' as series, h.hashtag_name as label ',
'     from statistics s',
'     join aweme a',
'     on s.aweme_id = a.aweme_id',
'     join hashtags h',
'     on h.aweme_id = a.aweme_id',
'     group by',
'            h.hashtag_name',
'     order by sum(s.play_count) desc',
'     ~'';',
'    end if;',
'',
'    ',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_HASHTAGS rows only ~'';',
'    ',
'',
'return l_sql;',
'',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6767304111678003)
,p_chart_id=>wwv_flow_imp.id(19279320179155385)
,p_seq=>20
,p_name=>'Likes'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'l_sql := q''~select sum(s.digg_count) ~'';',
'',
'if :P6_AVERAGE_HASHTAG = 0 then',
'    l_sql := l_sql || q''~ ',
'     as value, ''Likes'' as series, h.hashtag_name as label ',
'     from statistics s',
'     join aweme a',
'     on s.aweme_id = a.aweme_id',
'     join hashtags h',
'     on h.aweme_id = a.aweme_id',
'     group by',
'            h.hashtag_name',
'     order by sum(s.play_count) desc',
'     ~'';',
'else',
'    l_sql := l_sql || q''~',
'     /count(h.aweme_id) as value, ''Likes'' as series, h.hashtag_name as label ',
'     from statistics s',
'     join aweme a',
'     on s.aweme_id = a.aweme_id',
'     join hashtags h',
'     on h.aweme_id = a.aweme_id',
'     group by',
'            h.hashtag_name',
'     order by sum(s.play_count) desc',
'     ~'';',
'    end if;',
'',
'    ',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_HASHTAGS rows only ~'';',
'    ',
'',
'return l_sql;',
'',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19279585362155388)
,p_chart_id=>wwv_flow_imp.id(19279320179155385)
,p_seq=>30
,p_name=>'Views'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'l_sql := q''~select sum(s.play_count) ~'';',
'',
'if :P6_AVERAGE_HASHTAG = 0 then',
'    l_sql := l_sql || q''~ ',
'     as value, ''Views'' as series, h.hashtag_name as label ',
'     from statistics s',
'     join aweme a',
'     on s.aweme_id = a.aweme_id',
'     join hashtags h',
'     on h.aweme_id = a.aweme_id',
'     group by',
'            h.hashtag_name',
'     order by sum(s.play_count) desc',
'     ~'';',
'else',
'    l_sql := l_sql || q''~',
'     /count(h.aweme_id) as value, ''Views'' as series, h.hashtag_name as label ',
'     from statistics s',
'     join aweme a',
'     on s.aweme_id = a.aweme_id',
'     join hashtags h',
'     on h.aweme_id = a.aweme_id',
'     group by',
'            h.hashtag_name',
'     order by sum(s.play_count) desc',
'     ~'';',
'    end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_HASHTAGS rows only ~'';',
'    ',
'return l_sql;',
'',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19279465413155387)
,p_chart_id=>wwv_flow_imp.id(19279320179155385)
,p_seq=>40
,p_name=>'Downloads'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'l_sql := q''~select sum(s.download_count) ~'';',
'',
'if :P6_AVERAGE_HASHTAG = 0 then',
'    l_sql := l_sql || q''~ ',
'     as value, ''Downloads'' as series, h.hashtag_name as label ',
'     from statistics s',
'     join aweme a',
'     on s.aweme_id = a.aweme_id',
'     join hashtags h',
'     on h.aweme_id = a.aweme_id',
'     group by',
'            h.hashtag_name',
'     order by sum(s.play_count) desc',
'     ~'';',
'else',
'    l_sql := l_sql || q''~',
'     /count(h.aweme_id) as value, ''Downloads'' as series, h.hashtag_name as label ',
'     from statistics s',
'     join aweme a',
'     on s.aweme_id = a.aweme_id',
'     join hashtags h',
'     on h.aweme_id = a.aweme_id',
'     group by',
'            h.hashtag_name',
'     order by sum(s.play_count) desc',
'     ~'';',
'    end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_HASHTAGS rows only ~'';',
'    ',
'return l_sql;',
'',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19279724546155389)
,p_chart_id=>wwv_flow_imp.id(19279320179155385)
,p_seq=>60
,p_name=>'Shares'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'l_sql := q''~select sum(s.share_count) ~'';',
'',
'if :P6_AVERAGE_HASHTAG = 0 then',
'    l_sql := l_sql || q''~ ',
'     as value, ''Shares'' as series, h.hashtag_name as label ',
'     from statistics s',
'     join aweme a',
'     on s.aweme_id = a.aweme_id',
'     join hashtags h',
'     on h.aweme_id = a.aweme_id',
'     group by',
'            h.hashtag_name',
'     order by sum(s.play_count) desc',
'     ~'';',
'else',
'    l_sql := l_sql || q''~',
'     /count(h.aweme_id) as value, ''Shares'' as series, h.hashtag_name as label ',
'     from statistics s',
'     join aweme a',
'     on s.aweme_id = a.aweme_id',
'     join hashtags h',
'     on h.aweme_id = a.aweme_id',
'     group by',
'            h.hashtag_name',
'     order by sum(s.play_count) desc',
'     ~'';',
'    end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_HASHTAGS rows only ~'';',
'    ',
'return l_sql;',
'',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19279770211155390)
,p_chart_id=>wwv_flow_imp.id(19279320179155385)
,p_seq=>70
,p_name=>'Whatsapp shares'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'l_sql := q''~select sum(s.whatsapp_share_count) ~'';',
'',
'if :P6_AVERAGE_HASHTAG = 0 then',
'    l_sql := l_sql || q''~ ',
'     as value, ''Whatsapp Shares'' as series, h.hashtag_name as label ',
'     from statistics s',
'     join aweme a',
'     on s.aweme_id = a.aweme_id',
'     join hashtags h',
'     on h.aweme_id = a.aweme_id',
'     group by',
'            h.hashtag_name',
'     order by sum(s.play_count) desc',
'     ~'';',
'else',
'    l_sql := l_sql || q''~',
'     /count(h.aweme_id) as value, ''Whatsapp Shares'' as series, h.hashtag_name as label ',
'     from statistics s',
'     join aweme a',
'     on s.aweme_id = a.aweme_id',
'     join hashtags h',
'     on h.aweme_id = a.aweme_id',
'     group by',
'            h.hashtag_name',
'     order by sum(s.play_count) desc',
'     ~'';',
'    end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_HASHTAGS rows only ~'';',
'    ',
'return l_sql;',
'',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(19279831831155391)
,p_chart_id=>wwv_flow_imp.id(19279320179155385)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Hashtag'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(19280007742155392)
,p_chart_id=>wwv_flow_imp.id(19279320179155385)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Interactions'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19355615457387310)
,p_plug_name=>'Compare two Hashtags'
,p_parent_plug_id=>wwv_flow_imp.id(19278776715155380)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19355666916387311)
,p_plug_name=>'Statistics first hashtag'
,p_region_name=>'first_hashtag'
,p_parent_plug_id=>wwv_flow_imp.id(19355615457387310)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'if :P6_AVERAGE_HASHTAG = 0 then',
'    l_sql := q''~ select sum(s.comment_count) as value, ''Comments'' as label',
'         from statistics s',
'         join hashtags h',
'         on h.aweme_id = s.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_1',
'         group by',
'                h.hashtag_name',
'        union all',
'        select sum(s.digg_count) as value, ''Likes'' as label',
'         from statistics s',
'         join hashtags h',
'         on h.aweme_id = s.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_1',
'         group by ',
'                h.hashtag_name',
'        union all',
'        select  sum(s.play_count) as value, ''Views'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_1',
'         group by',
'                h.hashtag_name',
'        union all ',
'        select  sum(s.download_count) as value, ''Downloads'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_1',
'         group by',
'                h.hashtag_name',
'        union all',
'        select  sum(s.share_count) as value, ''Shares'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_1',
'         group by',
'                h.hashtag_name',
'        union all',
'        select  sum(s.whatsapp_share_count) as value, ''Whatsapp Shares'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_1',
'         group by',
'                h.hashtag_name',
'     ~'';',
'else',
'    l_sql := ',
'        q''~select sum(s.comment_count)/count(s.aweme_id) as value, ''Comments'' as label',
'         from statistics s',
'         join hashtags h',
'         on h.aweme_id = s.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_1',
'         group by',
'                h.hashtag_name',
'        union all',
'        select sum(s.digg_count)/count(s.aweme_id) as value, ''Likes'' as label',
'         from statistics s',
'         join hashtags h',
'         on h.aweme_id = s.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_1',
'         group by ',
'                h.hashtag_name',
'        union all',
'        select  sum(s.play_count)/count(s.aweme_id) as value, ''Views'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_1',
'         group by',
'                h.hashtag_name',
'        union all ',
'        select  sum(s.download_count)/count(s.aweme_id) as value, ''Downloads'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_1',
'         group by',
'                h.hashtag_name',
'        union all',
'        select  sum(s.share_count)/count(s.aweme_id) as value, ''Shares'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_1',
'         group by',
'                h.hashtag_name',
'        union all',
'        select  sum(s.whatsapp_share_count)/count(s.aweme_id) as value, ''Whatsapp Shares'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_1',
'         group by',
'                h.hashtag_name',
'        ~'';',
'end if;',
'',
'return l_sql;',
'end;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sum(s.comment_count) as value, ''Comments'' as label',
' from statistics s',
' join hashtags h',
' on h.aweme_id = s.aweme_id',
' where h.hashtag_id = :P6_HASHTAG_1',
' group by',
'        h.hashtag_name',
'union all ',
'select  sum(s.download_count) as value, ''downloads'' as label',
' from statistics s',
' join hashtags h',
' on s.aweme_id = h.aweme_id',
' where h.hashtag_id = :P6_HASHTAG_1',
' group by',
'        h.hashtag_name',
'union all',
'select  sum(s.play_count) as value, ''views'' as label',
' from statistics s',
' join hashtags h',
' on s.aweme_id = h.aweme_id',
' where h.hashtag_id = :P6_HASHTAG_1',
' group by',
'        h.hashtag_name',
'union all',
'select  sum(s.share_count) as value, ''shares'' as label',
' from statistics s',
' join hashtags h',
' on s.aweme_id = h.aweme_id',
' where h.hashtag_id = :P6_HASHTAG_1',
' group by',
'        h.hashtag_name',
'union all',
'select  sum(s.whatsapp_share_count) as value, ''whatsapp shares'' as label',
' from statistics s',
' join hashtags h',
' on s.aweme_id = h.aweme_id',
' where h.hashtag_id = :P6_HASHTAG_1',
' group by',
'        h.hashtag_name'))
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(19355790117387312)
,p_region_id=>wwv_flow_imp.id(19355666916387311)
,p_chart_type=>'donut'
,p_title=>'First Hashtag'
,p_height=>'300'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlightAndExplode'
,p_no_data_found_message=>'No data found'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){',
'',
'    options.styleDefaults = { pieInnerRadius: 0.85 };',
'    options.pieCenter = { label : apex.item("P6_TOPIC_1").displayValueFor()};// + " "+$v("P8_HC_INTERN_1") };',
'    ',
'    options.dataFilter = function( data ) { ',
'        var groupLength = data.series.length;',
'        if (groupLength == 1){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            return data; ',
'        }else if(groupLength == 2){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            return data; ',
'        }else if(groupLength == 3){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            return data;  ',
'        }else if(groupLength == 4){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            return data;',
'        }else if(groupLength == 5){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            return data; ',
'        }else if(groupLength ==6){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            data.series[ 5 ].color = "#a8a4e4";',
'            return data;',
'        }else',
'            return data;',
'    };',
'    return options;',
'} ',
'',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19355903862387313)
,p_chart_id=>wwv_flow_imp.id(19355790117387312)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19355971578387314)
,p_plug_name=>'Statistics second hashtag'
,p_region_name=>'second_hashtag'
,p_parent_plug_id=>wwv_flow_imp.id(19355615457387310)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'l_sql CLOB;',
'begin',
'',
'if :P6_AVERAGE_HASHTAG = 0 then',
'    l_sql := q''~ select sum(s.comment_count) as value, ''Comments'' as label',
'         from statistics s',
'         join hashtags h',
'         on h.aweme_id = s.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_2',
'         group by',
'                h.hashtag_name',
'        union all',
'        select sum(s.digg_count) as value, ''Likes'' as label',
'         from statistics s',
'         join hashtags h',
'         on h.aweme_id = s.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_2',
'         group by ',
'                h.hashtag_name',
'        union all',
'        select  sum(s.play_count) as value, ''Views'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_2',
'         group by',
'                h.hashtag_name',
'        union all ',
'        select  sum(s.download_count) as value, ''Downloads'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_2',
'         group by',
'                h.hashtag_name',
'        union all',
'        select  sum(s.share_count) as value, ''Shares'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_2',
'         group by',
'                h.hashtag_name',
'        union all',
'        select  sum(s.whatsapp_share_count) as value, ''Whatsapp Shares'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_2',
'         group by',
'                h.hashtag_name',
'     ~'';',
'else',
'    l_sql := ',
'        q''~select sum(s.comment_count)/count(s.aweme_id) as value, ''Comments'' as label',
'         from statistics s',
'         join hashtags h',
'         on h.aweme_id = s.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_2',
'         group by',
'                h.hashtag_name',
'        union all',
'        select sum(s.digg_count)/count(s.aweme_id) as value, ''Likes'' as label',
'         from statistics s',
'         join hashtags h',
'         on h.aweme_id = s.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_2',
'         group by ',
'                h.hashtag_name',
'        union all',
'        select  sum(s.play_count)/count(s.aweme_id) as value, ''Views'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_2',
'         group by',
'                h.hashtag_name',
'        union all ',
'        select  sum(s.download_count)/count(s.aweme_id) as value, ''Downloads'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_2',
'         group by',
'                h.hashtag_name',
'        union all',
'        select  sum(s.share_count)/count(s.aweme_id) as value, ''Shares'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_2',
'         group by',
'                h.hashtag_name',
'        union all',
'        select  sum(s.whatsapp_share_count)/count(s.aweme_id) as value, ''Whatsapp Shares'' as label',
'         from statistics s',
'         join hashtags h',
'         on s.aweme_id = h.aweme_id',
'         where h.hashtag_name = :P6_HASHTAG_2',
'         group by',
'                h.hashtag_name',
'        ~'';',
'end if;',
'',
'return l_sql;',
'end;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(19356126091387315)
,p_region_id=>wwv_flow_imp.id(19355971578387314)
,p_chart_type=>'donut'
,p_title=>'Second hashtag'
,p_height=>'300'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlightAndExplode'
,p_no_data_found_message=>'No data found'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){',
'',
'    options.styleDefaults = { pieInnerRadius: 0.85 };',
'    options.pieCenter = { label :$v("P6_TOPIC_2") + " " };',
'    ',
'    options.dataFilter = function( data ) { ',
'        var groupLength = data.series.length;',
'        if (groupLength == 1){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            return data; ',
'        }else if(groupLength == 2){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            return data; ',
'        }else if(groupLength == 3){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            return data;  ',
'        }else if(groupLength == 4){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            return data;',
'        }else if(groupLength == 5){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            return data; ',
'        }else if(groupLength ==6){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            data.series[ 5 ].color = "#a8a4e4";',
'            return data;',
'        }else',
'            return data;',
'    };',
'    return options;',
'} ',
'',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19356206752387316)
,p_chart_id=>wwv_flow_imp.id(19356126091387315)
,p_seq=>10
,p_name=>'New'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19356929477387324)
,p_plug_name=>'Video and audio'
,p_parent_plug_id=>wwv_flow_imp.id(19039631503018680)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19357271329387327)
,p_plug_name=>'Engagement by Tiktok Duration'
,p_region_name=>'EngagementByDuration'
,p_parent_plug_id=>wwv_flow_imp.id(19356929477387324)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>5716083853041667
,p_default_application_id=>104
,p_default_id_offset=>6116328087839079
,p_default_owner=>'MADHACKS'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(19357352775387328)
,p_region_id=>wwv_flow_imp.id(19357271329387327)
,p_chart_type=>'bar'
,p_title=>'Engagement by Tiktok Duration'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'value-desc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){',
'',
'    //options.styleDefaults = { pieInnerRadius: 0.85 };',
'    //options.pieCenter = { label : apex.item("P6_TOPIC_1").getValue() + "Printing something"};',
'    ',
'    options.dataFilter = function( data ) { ',
'        var groupLength = data.series.length;',
'        if (groupLength == 1){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            return data; ',
'        }else if(groupLength == 2){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            return data; ',
'        }else if(groupLength == 3){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            return data;  ',
'        }else if(groupLength == 4){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            return data;',
'        }else if(groupLength == 5){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            return data; ',
'        }else if(groupLength ==6){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            data.series[ 5 ].color = "#a8a4e4";',
'            return data;',
'        }else',
'            return data;',
'    };',
'    return options;',
'} ',
'',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19357448597387329)
,p_chart_id=>wwv_flow_imp.id(19357352775387328)
,p_seq=>10
,p_name=>'Comments'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_sql CLOB;',
'begin',
'',
'l_sql := q''~ select sum(s.comment_count) ~'';',
'',
'if :P6_AVERAGE_MUSIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Comments'' as series, (floor((duration/100)/20) * 20)|| '' - '' ||((floor((duration/100)/20) * 20) + 20) as label',
'        from statistics s',
'        join video v',
'        on s.aweme_id = v.aweme_id',
'        group by floor((duration/100)/20)',
'        order by sum(s.play_count) desc',
'        ~'';',
'else ',
'    l_sql := l_sql || q''~ /count(s.aweme_id) as value, ''Comments'' as series, (floor((duration/100)/20) * 20)|| '' - '' ||((floor((duration/100)/20) * 20) + 20) as label',
'        from statistics s',
'        join video v',
'        on s.aweme_id = v.aweme_id',
'        group by floor((duration/100)/20)',
'        order by sum(s.play_count) desc',
'        ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_DURATION rows only ~'';',
'return l_sql;',
'end;',
'',
'',
''))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6767430794678004)
,p_chart_id=>wwv_flow_imp.id(19357352775387328)
,p_seq=>20
,p_name=>'Likes'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_sql CLOB;',
'begin',
'',
'l_sql := q''~ select sum(s.digg_count) ~'';',
'',
'if :P6_AVERAGE_MUSIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Likes'' as series, (floor((duration/100)/20) * 20)|| '' - '' ||((floor((duration/100)/20) * 20) + 20) as label',
'        from statistics s',
'        join video v',
'        on s.aweme_id = v.aweme_id',
'        group by floor((duration/100)/20)',
'        order by sum(s.play_count) desc',
'        ~'';',
'else ',
'    l_sql := l_sql || q''~ /count(s.aweme_id) as value, ''Likes'' as series, (floor((duration/100)/20) * 20)|| '' - '' ||((floor((duration/100)/20) * 20) + 20) as label',
'        from statistics s',
'        join video v',
'        on s.aweme_id = v.aweme_id',
'        group by floor((duration/100)/20)',
'        order by sum(s.play_count) desc',
'        ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_DURATION rows only ~'';',
'return l_sql;',
'end;',
'',
'',
''))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19396618150501881)
,p_chart_id=>wwv_flow_imp.id(19357352775387328)
,p_seq=>30
,p_name=>'Views'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_sql CLOB;',
'begin',
'',
'l_sql := q''~ select sum(s.play_count) ~'';',
'',
'if :P6_AVERAGE_MUSIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Views'' as series, (floor((duration/100)/20) * 20)|| '' - '' ||((floor((duration/100)/20) * 20) + 20) as label',
'        from statistics s',
'        join video v',
'        on s.aweme_id = v.aweme_id',
'        group by floor((duration/100)/20)',
'        order by sum(s.play_count) desc',
'        ~'';',
'else ',
'    l_sql := l_sql || q''~ /count(s.aweme_id) as value, ''Views'' as series, (floor((duration/100)/20) * 20)|| '' - '' ||((floor((duration/100)/20) * 20) + 20) as label',
'        from statistics s',
'        join video v',
'        on s.aweme_id = v.aweme_id',
'        group by floor((duration/100)/20)',
'        order by sum(s.play_count) desc',
'        ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_DURATION rows only ~'';',
'    ',
'return l_sql;',
'end;',
'',
'',
''))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19396479155501880)
,p_chart_id=>wwv_flow_imp.id(19357352775387328)
,p_seq=>40
,p_name=>'Downloads'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_sql CLOB;',
'begin',
'',
'l_sql := q''~ select sum(s.download_count) ~'';',
'',
'if :P6_AVERAGE_MUSIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Downloads'' as series, (floor((duration/100)/20) * 20)|| '' - '' ||((floor((duration/100)/20) * 20) + 20) as label',
'        from statistics s',
'        join video v',
'        on s.aweme_id = v.aweme_id',
'        group by floor((duration/100)/20)',
'        order by sum(s.play_count) desc',
'        ~'';',
'else ',
'    l_sql := l_sql || q''~ /count(s.aweme_id) as value, ''Downloads'' as series, (floor((duration/100)/20) * 20)|| '' - '' ||((floor((duration/100)/20) * 20) + 20) as label',
'        from statistics s',
'        join video v',
'        on s.aweme_id = v.aweme_id',
'        group by floor((duration/100)/20)',
'        order by sum(s.play_count) desc',
'        ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_DURATION rows only ~'';',
'    ',
'return l_sql;',
'end;',
'',
'',
''))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19396642304501882)
,p_chart_id=>wwv_flow_imp.id(19357352775387328)
,p_seq=>60
,p_name=>'Shares'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_sql CLOB;',
'begin',
'',
'l_sql := q''~ select sum(s.share_count) ~'';',
'',
'if :P6_AVERAGE_MUSIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Shares'' as series, (floor((duration/100)/20) * 20)|| '' - '' ||((floor((duration/100)/20) * 20) + 20) as label',
'        from statistics s',
'        join video v',
'        on s.aweme_id = v.aweme_id',
'        group by floor((duration/100)/20)',
'        order by sum(s.play_count) desc',
'        ~'';',
'else ',
'    l_sql := l_sql || q''~ /count(s.aweme_id) as value, ''Shares'' as series, (floor((duration/100)/20) * 20)|| '' - '' ||((floor((duration/100)/20) * 20) + 20) as label',
'        from statistics s',
'        join video v',
'        on s.aweme_id = v.aweme_id',
'        group by floor((duration/100)/20)',
'        order by sum(s.play_count) desc',
'        ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_DURATION rows only ~'';',
'    ',
'return l_sql;',
'end;',
'',
'',
''))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19396790375501883)
,p_chart_id=>wwv_flow_imp.id(19357352775387328)
,p_seq=>70
,p_name=>'Whatsapp shares'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' l_sql CLOB;',
'begin',
'',
'l_sql := q''~ select sum(s.whatsapp_share_count) ~'';',
'',
'if :P6_AVERAGE_MUSIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Whatsapp shares'' as series, (floor((duration/100)/20) * 20)|| '' - '' ||((floor((duration/100)/20) * 20) + 20) as label',
'        from statistics s',
'        join video v',
'        on s.aweme_id = v.aweme_id',
'        group by floor((duration/100)/20)',
'        order by sum(s.play_count) desc',
'        ~'';',
'else ',
'    l_sql := l_sql || q''~ /count(s.aweme_id) as value, ''Whatsapp shares'' as series, (floor((duration/100)/20) * 20)|| '' - '' ||((floor((duration/100)/20) * 20) + 20) as label',
'        from statistics s',
'        join video v',
'        on s.aweme_id = v.aweme_id',
'        group by floor((duration/100)/20)',
'        order by sum(s.play_count) desc',
'        ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_DURATION rows only ~'';',
'    ',
'return l_sql;',
'end;',
'',
'',
''))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(19396907741501884)
,p_chart_id=>wwv_flow_imp.id(19357352775387328)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Tiktok Duration in seconds'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(19396954436501885)
,p_chart_id=>wwv_flow_imp.id(19357352775387328)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Interactions'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19397204592501887)
,p_plug_name=>'Engagement by Music'
,p_region_name=>'EngagementByMusic'
,p_parent_plug_id=>wwv_flow_imp.id(19356929477387324)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(14361856586241894)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(19397319889501888)
,p_region_id=>wwv_flow_imp.id(19397204592501887)
,p_chart_type=>'bar'
,p_title=>'Engagement by Music'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'value-desc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){',
'',
'    //options.styleDefaults = { pieInnerRadius: 0.85 };',
'    //options.pieCenter = { label : apex.item("P6_TOPIC_1").getValue() + "Printing something"};',
'    ',
'    options.dataFilter = function( data ) { ',
'        var groupLength = data.series.length;',
'        if (groupLength == 1){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            return data; ',
'        }else if(groupLength == 2){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            return data; ',
'        }else if(groupLength == 3){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            return data;  ',
'        }else if(groupLength == 4){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            return data;',
'        }else if(groupLength == 5){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            return data; ',
'        }else if(groupLength ==6){',
'            data.series[ 0 ].color = "#AE562C"; ',
'            data.series[ 1 ].color = "#FACD62"; ',
'            data.series[ 2 ].color = "#94AFAF"; ',
'            data.series[ 3 ].color = "#759C6C"; ',
'            data.series[ 4 ].color = "#2B6242"; ',
'            data.series[ 5 ].color = "#a8a4e4";',
'            return data;',
'        }else',
'            return data;',
'    };',
'    return options;',
'} ',
'',
''))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19397412574501889)
,p_chart_id=>wwv_flow_imp.id(19397319889501888)
,p_seq=>10
,p_name=>'Comments'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'begin',
'',
'    l_sql := q''~ select sum(s.comment_count) ~'';',
'',
'if :P6_AVERAGE_MUSIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Comments'' as series, m.title as label',
'            from statistics s',
'            join music_info m',
'            on s.aweme_id = m.aweme_id',
'            group by m.title',
'            order by sum(s.play_count) desc',
'            ~'';',
'else',
'    l_sql := l_sql || q''~/count(s.aweme_id) as value, ''Comments'' as series, m.title as label',
'            from statistics s',
'            join music_info m',
'            on s.aweme_id = m.aweme_id',
'            group by m.title',
'            order by sum(s.play_count) desc',
'            ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_MUSIC rows only ~'';',
'    ',
'return l_sql;',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6767537201678005)
,p_chart_id=>wwv_flow_imp.id(19397319889501888)
,p_seq=>20
,p_name=>'Likes'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'begin',
'',
'    l_sql := q''~ select sum(s.digg_count) ~'';',
'',
'if :P6_AVERAGE_MUSIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Likes'' as series, m.title as label',
'            from statistics s',
'            join music_info m',
'            on s.aweme_id = m.aweme_id',
'            group by m.title',
'            order by sum(s.play_count) desc',
'            ~'';',
'else',
'    l_sql := l_sql || q''~/count(s.aweme_id) as value, ''Likes'' as series, m.title as label',
'            from statistics s',
'            join music_info m',
'            on s.aweme_id = m.aweme_id',
'            group by m.title',
'            order by sum(s.play_count) desc',
'            ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_MUSIC rows only ~'';',
'    ',
'return l_sql;',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19397578980501891)
,p_chart_id=>wwv_flow_imp.id(19397319889501888)
,p_seq=>30
,p_name=>'Views'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'begin',
'',
'    l_sql := q''~ select sum(s.play_count) ~'';',
'',
'if :P6_AVERAGE_MUSIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Views'' as series, m.title as label',
'            from statistics s',
'            join music_info m',
'            on s.aweme_id = m.aweme_id',
'            group by m.title',
'            order by sum(s.play_count) desc',
'            ~'';',
'else',
'    l_sql := l_sql || q''~/count(s.aweme_id) as value, ''Views'' as series, m.title as label',
'            from statistics s',
'            join music_info m',
'            on s.aweme_id = m.aweme_id',
'            group by m.title',
'            order by sum(s.play_count) desc',
'            ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_MUSIC rows only ~'';',
'    ',
'return l_sql;',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19397428289501890)
,p_chart_id=>wwv_flow_imp.id(19397319889501888)
,p_seq=>40
,p_name=>'Downloads'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'begin',
'',
'    l_sql := q''~ select sum(s.download_count) ~'';',
'',
'if :P6_AVERAGE_MUSIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Downloads'' as series, m.title as label',
'            from statistics s',
'            join music_info m',
'            on s.aweme_id = m.aweme_id',
'            group by m.title',
'            order by sum(s.play_count) desc',
'            ~'';',
'else',
'    l_sql := l_sql || q''~/count(s.aweme_id) as value, ''Downloads'' as series, m.title as label',
'            from statistics s',
'            join music_info m',
'            on s.aweme_id = m.aweme_id',
'            group by m.title',
'            order by sum(s.play_count) desc',
'            ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_MUSIC rows only ~'';',
'',
'return l_sql;',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19397662817501892)
,p_chart_id=>wwv_flow_imp.id(19397319889501888)
,p_seq=>60
,p_name=>'Shares'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'begin',
'',
'    l_sql := q''~ select sum(s.share_count) ~'';',
'',
'if :P6_AVERAGE_MUSIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Shares'' as series, m.title as label',
'            from statistics s',
'            join music_info m',
'            on s.aweme_id = m.aweme_id',
'            group by m.title',
'            order by sum(s.play_count) desc',
'            ~'';',
'else',
'    l_sql := l_sql || q''~/count(s.aweme_id) as value, ''Shares'' as series, m.title as label',
'            from statistics s',
'            join music_info m',
'            on s.aweme_id = m.aweme_id',
'            group by m.title',
'            order by sum(s.play_count) desc',
'            ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_MUSIC rows only ~'';',
'    ',
'return l_sql;',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(19397764092501893)
,p_chart_id=>wwv_flow_imp.id(19397319889501888)
,p_seq=>70
,p_name=>'Whatsapp shares'
,p_data_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'begin',
'',
'    l_sql := q''~ select sum(s.whatsapp_share_count) ~'';',
'',
'if :P6_AVERAGE_MUSIC = 0 then',
'    l_sql := l_sql || q''~ as value, ''Whatsapp Shares'' as series, m.title as label',
'            from statistics s',
'            join music_info m',
'            on s.aweme_id = m.aweme_id',
'            group by m.title',
'            order by sum(s.play_count) desc',
'            ~'';',
'else',
'    l_sql := l_sql || q''~/count(s.aweme_id) as value, ''Whatsapp Shares'' as series, m.title as label',
'            from statistics s',
'            join music_info m',
'            on s.aweme_id = m.aweme_id',
'            group by m.title',
'            order by sum(s.play_count) desc',
'            ~'';',
'end if;',
'',
'    l_sql := l_sql || q''~ fetch first :P6_TOP_MUSIC rows only ~'';',
'    ',
'return l_sql;',
'end;'))
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(19397847752501894)
,p_chart_id=>wwv_flow_imp.id(19397319889501888)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Song Title'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(19397999894501895)
,p_chart_id=>wwv_flow_imp.id(19397319889501888)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Interactions'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19440671625372911)
,p_plug_name=>'Filters'
,p_parent_plug_id=>wwv_flow_imp.id(19356929477387324)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14327931109241878)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19041047692018694)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(19438711149372891)
,p_button_name=>'Stack_topic'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillStart'
,p_button_template_id=>wwv_flow_imp.id(14426281116241933)
,p_button_image_alt=>'Stack'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19280085134155393)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(19279183613155384)
,p_button_name=>'Stack_hashtag'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillStart'
,p_button_template_id=>wwv_flow_imp.id(14426281116241933)
,p_button_image_alt=>'Stack'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19398054833501896)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(19357271329387327)
,p_button_name=>'Stack_duration'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(14426281116241933)
,p_button_image_alt=>'Stack'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19041331300018697)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(19438711149372891)
,p_button_name=>'Unstack_topic'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillEnd'
,p_button_template_id=>wwv_flow_imp.id(14426281116241933)
,p_button_image_alt=>'Unstack'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19398164072501897)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(19357271329387327)
,p_button_name=>'Unstack_duration'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(14426281116241933)
,p_button_image_alt=>'Unstack'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19398819408501903)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(19397204592501887)
,p_button_name=>'Stack_music'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(14426281116241933)
,p_button_image_alt=>'Stack'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19280422640155396)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(19279183613155384)
,p_button_name=>'Unstack_hashtag'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--pillEnd'
,p_button_template_id=>wwv_flow_imp.id(14426281116241933)
,p_button_image_alt=>'Unstack'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19398902328501904)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(19397204592501887)
,p_button_name=>'Unstack_music'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(14426281116241933)
,p_button_image_alt=>'Unstack'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19040229774018686)
,p_name=>'P6_AVERAGE_HASHTAG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(19278889692155381)
,p_item_default=>'1'
,p_prompt=>'Average Engagement by hashtag'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_attribute_04=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19040399649018687)
,p_name=>'P6_AVERAGE_TOPIC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(19044618971018729)
,p_item_default=>'1'
,p_prompt=>'Average Engagement by topic'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_attribute_04=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19281446997155407)
,p_name=>'P6_TOPIC_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(19280828403155401)
,p_use_cache_before_default=>'NO'
,p_prompt=>'First Topic'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct topic as d, topic as r',
'from aweme_topics',
'order by topic asc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select a topic to compare - '
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19282314950155415)
,p_name=>'P6_TOPIC_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(19281979511155412)
,p_use_cache_before_default=>'NO'
,p_prompt=>'First Topic'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct topic as d, topic as r',
'from aweme_topics',
'order by topic asc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select a topic to compare - '
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19356228302387317)
,p_name=>'P6_HASHTAG_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(19355666916387311)
,p_prompt=>'First Hashtag '
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct hashtag_name as d, hashtag_name as r',
'from hashtags',
'order by hashtag_name asc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select a hashtag to compare -'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>5716083853041667
,p_default_application_id=>104
,p_default_id_offset=>6116328087839079
,p_default_owner=>'MADHACKS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19356413794387318)
,p_name=>'P6_HASHTAG_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(19355971578387314)
,p_prompt=>'Second Hashtag'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct hashtag_name as d, hashtag_name as r',
'from hashtags',
'order by hashtag_name asc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select a hashtag to compare -'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19440815003372912)
,p_name=>'P6_AVERAGE_MUSIC'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(19440671625372911)
,p_item_default=>'1'
,p_prompt=>'Average Engagement'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_attribute_04=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19441245924372917)
,p_name=>'P6_TOP_TOPICS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(19044618971018729)
,p_item_default=>'20'
,p_prompt=>'Top Topics'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'1'
,p_attribute_02=>'50'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19441390527372918)
,p_name=>'P6_TOP_HASHTAGS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(19278889692155381)
,p_item_default=>'20'
,p_prompt=>'Top Hashtags'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'1'
,p_attribute_02=>'50'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19441504885372919)
,p_name=>'P6_TOP_DURATION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(19440671625372911)
,p_item_default=>'20'
,p_prompt=>'Top Duration'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'1'
,p_attribute_02=>'50'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19441583465372920)
,p_name=>'P6_TOP_MUSIC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(19440671625372911)
,p_item_default=>'20'
,p_prompt=>'Top Music'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(14423769035241930)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'1'
,p_attribute_02=>'50'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19041138768018695)
,p_name=>'Stack chart'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19041047692018694)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19441634077372921)
,p_event_id=>wwv_flow_imp.id(19041138768018695)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.region("EngagementByTopic").widget().ojChart({stack: ''on''});'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19280208595155394)
,p_name=>'Stack chart_1'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19280085134155393)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19441839201372923)
,p_event_id=>wwv_flow_imp.id(19280208595155394)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.region("EngagementByHashtag").widget().ojChart({stack: ''on''});'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19041515386018698)
,p_name=>'Unstack chart'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19041331300018697)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19441768839372922)
,p_event_id=>wwv_flow_imp.id(19041515386018698)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.region("EngagementByTopic").widget().ojChart({stack: ''off''});'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19280491693155397)
,p_name=>'Unstack chart_1'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19280422640155396)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19441951234372924)
,p_event_id=>wwv_flow_imp.id(19280491693155397)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.region("EngagementByHashtag").widget().ojChart({stack: ''off''});'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19281619313155408)
,p_name=>'Refresh'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_TOPIC_1,P6_TOPIC_2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19281829649155411)
,p_event_id=>wwv_flow_imp.id(19281619313155408)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'NULL;',
'END;'))
,p_attribute_02=>'P6_TOPIC_1,P6_TOPIC_2'
,p_attribute_05=>'PLSQL'
,p_stop_execution_on_error=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19281764463155410)
,p_event_id=>wwv_flow_imp.id(19281619313155408)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.region("first_topic").refresh();',
'apex.region("first_topic").call( "option", "pieCenter", { label: $v(''P6_TOPIC_1'') } );'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19282428325155417)
,p_event_id=>wwv_flow_imp.id(19281619313155408)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.region("second_topic").refresh();',
'apex.region("second_topic").call( "option", "pieCenter", { label: $v(''P6_TOPIC_2'')} );'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19281642846155409)
,p_event_id=>wwv_flow_imp.id(19281619313155408)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19280828403155401)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19282400253155416)
,p_event_id=>wwv_flow_imp.id(19281619313155408)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19281979511155412)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19356433770387319)
,p_name=>'Refresh '
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_HASHTAG_1,P6_HASHTAG_2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19356607291387320)
,p_event_id=>wwv_flow_imp.id(19356433770387319)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'NULL;',
'END;'))
,p_attribute_02=>'P6_HASHTAG_1,P6_HASHTAG_2'
,p_attribute_05=>'PLSQL'
,p_stop_execution_on_error=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19356660011387321)
,p_event_id=>wwv_flow_imp.id(19356433770387319)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.region("first_hashtag").refresh();',
'apex.region("first_hashtag").call( "option", "pieCenter", { label: $v("P6_HASHTAG_1") } );'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19356884144387323)
,p_event_id=>wwv_flow_imp.id(19356433770387319)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.region("second_hashtag").refresh();',
'apex.region("second_hashtag").call( "option", "pieCenter", { label: $v(''P6_HASHTAG_2'') } );'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19398234802501898)
,p_name=>'Stack_duration'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19398054833501896)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19398412888501899)
,p_event_id=>wwv_flow_imp.id(19398234802501898)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.region("EngagementByDuration").widget().ojChart({stack: ''on''});'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19398621777501901)
,p_name=>'unstack_duration'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19398164072501897)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19398657290501902)
,p_event_id=>wwv_flow_imp.id(19398621777501901)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.region("EngagementByDuration").widget().ojChart({stack: ''off''});'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19398968751501905)
,p_name=>'Stack_music'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19398819408501903)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19399108174501906)
,p_event_id=>wwv_flow_imp.id(19398968751501905)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.region("EngagementByMusic").widget().ojChart({stack: ''on''});'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19399202921501907)
,p_name=>'Unstack_music'
,p_event_sequence=>160
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19398902328501904)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19399258375501908)
,p_event_id=>wwv_flow_imp.id(19399202921501907)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.region("EngagementByMusic").widget().ojChart({stack: ''off''});'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19439622481372900)
,p_name=>'Average_topic_filter'
,p_event_sequence=>170
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_AVERAGE_TOPIC,P6_TOP_TOPICS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19439815033372902)
,p_event_id=>wwv_flow_imp.id(19439622481372900)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'NULL;',
'END;'))
,p_attribute_02=>'P6_AVERAGE_TOPIC,P6_TOP_TOPICS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19439674654372901)
,p_event_id=>wwv_flow_imp.id(19439622481372900)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19438711149372891)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19439846587372903)
,p_event_id=>wwv_flow_imp.id(19439622481372900)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19280828403155401)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19439965440372904)
,p_event_id=>wwv_flow_imp.id(19439622481372900)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19281979511155412)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19440145946372906)
,p_name=>'Average_hashtag_filter'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_AVERAGE_HASHTAG,P6_TOP_HASHTAGS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19440237023372907)
,p_event_id=>wwv_flow_imp.id(19440145946372906)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'NULL;',
'END;'))
,p_attribute_02=>'P6_AVERAGE_HASHTAG,P6_TOP_HASHTAGS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19440421482372908)
,p_event_id=>wwv_flow_imp.id(19440145946372906)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19279183613155384)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19440458513372909)
,p_event_id=>wwv_flow_imp.id(19440145946372906)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19355666916387311)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19440605327372910)
,p_event_id=>wwv_flow_imp.id(19440145946372906)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19355971578387314)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19440835063372913)
,p_name=>'Average_music_filter'
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_AVERAGE_MUSIC,P6_TOP_DURATION,P6_TOP_MUSIC'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19440948951372914)
,p_event_id=>wwv_flow_imp.id(19440835063372913)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'NULL;',
'END;'))
,p_attribute_02=>'P6_AVERAGE_MUSIC,P6_TOP_DURATION,P6_TOP_MUSIC'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19441043994372915)
,p_event_id=>wwv_flow_imp.id(19440835063372913)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19397204592501887)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19441157343372916)
,p_event_id=>wwv_flow_imp.id(19440835063372913)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19357271329387327)
);
wwv_flow_imp.component_end;
end;
/
